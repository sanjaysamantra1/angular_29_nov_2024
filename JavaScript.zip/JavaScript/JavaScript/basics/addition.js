function add(a,b){

console.log(`Addition of ${a} and ${b} is ${a+b}`); // works for both front and backend
window.alert(`Addition of ${a} and ${b} is ${a+b}`); v// display alert / popup on top in frontned
document.write(`Addition of ${a} and ${b} is ${a+b}`);// write this in frontend page
}

add(10,12);