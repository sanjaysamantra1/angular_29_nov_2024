'use strict'

// var a=b=c=3;
// console.log(a,b,c); // if we use ' use strict ' we cant assign that value to b and c

// function add(a, a, a) { // SyntaxError: Duplicate parameter name not allowed in this context
//     console.log(a + a + a); // a = 2/3/4
// }
// add(2, 3, 4);



myName = 'Sachin Tendulkar';     // ReferenceError: myName is not defined
console.log('Name is:', myName);

